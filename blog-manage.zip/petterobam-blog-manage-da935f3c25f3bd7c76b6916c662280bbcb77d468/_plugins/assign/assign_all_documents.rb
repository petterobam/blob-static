module Jekyll
  class AssignAllDocuments < Generator
    safe true
    priority :highest

    def generate(site)
      all_documents = []

      # Add all posts and filter out hidden posts
      all_documents.concat(site.posts.docs.reject { |post| post.data['action'] == 'hide' })

      # Add all documents from custom collections and filter out hidden documents
      site.collections.each do |_collection_name, collection|
        all_documents.concat(collection.docs.reject { |doc| doc.data['action'] == 'hide' })
      end

      # Assign the array to a site variable
      site.config['all_documents'] = all_documents
    end
  end
end
