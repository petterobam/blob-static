module Jekyll
  module CustomFilters
    def unique_sorted_field(input, targetField, sortField)
      # 初始化一个空的哈希表来存储唯一的 targetField 和对应的最大 sortField
      unique_hash = {}

      # 遍历输入的集合
      input.each do |item|
        target_value = item[targetField]
        sort_value = item[sortField].to_i  # 转换为整数（Unix时间戳）

        # 如果这是一个新的 targetField 或者新的 sortField 值更大，则更新哈希表
        if unique_hash[target_value].nil? || unique_hash[target_value] < sort_value
          unique_hash[target_value] = sort_value
        end
      end

      # 根据 sortField 对哈希表进行排序，并提取排序后的 targetField 值
      sorted_unique_array = unique_hash.sort_by { |_key, value| -value }.map { |item| item[0] }

      return sorted_unique_array
    end
  end
end

Liquid::Template.register_filter(Jekyll::CustomFilters)
