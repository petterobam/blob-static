module Jekyll
    module UniqueFilter
      def unique_by_field(array, field)
        unique_elements = []
        seen_fields = []
  
        array.each do |element|
          value = element.data[field] || element[field]
  
          unless seen_fields.include?(value)
            unique_elements << element
            seen_fields << value
          end
        end
  
        unique_elements
      end
    end
end
  
Liquid::Template.register_filter(Jekyll::UniqueFilter)
  